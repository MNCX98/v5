"""Phases 4 et 5 : jouer mon tour (lancer le sort sur l'adversaire le plus proche à portée,
puis finir le tour) et recommencer à chaque tour."""
import time
from datetime import datetime

import cv2
import numpy as np

from core import input as inp
from core.combat import (find_enemies, find_me, range_fraction, range_mask, range_visible,
                         sort_by_distance)
from core.grid import grid_distance
from core.imgio import save_image
from core.paths import logs_dir
from core.vision import scan
from phases.base import Context
from phases.p2_combat import read_ui


def _ui(ctx: Context, name: str):
    return [t for t in ctx.ui_templates if t.variant == name]


def _find(ctx: Context, scene, name: str):
    r = scan(scene, _ui(ctx, name), ctx.config.ui_threshold)
    return r.detections[0] if r.detections else None


def wait_my_turn(ctx: Context, should_stop):
    """Attend que le bouton « Fin du tour » soit vert. Retourne True si c'est mon tour."""
    t0 = time.time()
    while time.time() - t0 < ctx.config.turn_wait_s and not should_stop():
        scene, _ = ctx.capture.grab()
        if read_ui(scene, ctx.ui_templates, ctx.config.ui_threshold).turn_active:
            return True
        time.sleep(0.4)
    return False


def _diag(ctx: Context, scene, enemies, me, target=None, label="tour"):
    if not ctx.config.save_diagnostics:
        return
    out = scene.copy()
    for f in enemies:
        cv2.circle(out, f.center, 8, (0, 255, 255), -1)
    if me:
        cv2.circle(out, me.center, 10, (0, 0, 255), -1)
    if target:
        cv2.circle(out, target.center, 22, (0, 255, 0), 3)
    save_image(logs_dir() / f"{label}_{datetime.now():%Y%m%d_%H%M%S_%f}.png", out)


def _wait_confirm(ctx: Context, timeout: float = 1.6):
    t0 = time.time()
    while time.time() - t0 < timeout:
        scene, origin = ctx.capture.grab()
        d = _find(ctx, scene, "valider")
        if d:
            return d, origin
        time.sleep(0.2)
    return None, None


def _select_spell(ctx: Context) -> bool:
    scene, (ox, oy) = ctx.capture.grab()
    if range_visible(scene):
        return True                                   # déjà sélectionné
    icon = _find(ctx, scene, "sort_attaque")
    if not icon:
        ctx.log("⚠ Icône du sort introuvable.")
        return False
    inp.click(ox + icon.center[0], oy + icon.center[1])
    t0 = time.time()
    while time.time() - t0 < 1.8:
        time.sleep(0.3)
        s, _ = ctx.capture.grab()
        if range_visible(s):
            return True
    ctx.log("Le sort ne s'affiche pas (plus assez de PA ?).")
    return False


def play_turn(ctx: Context, should_stop) -> int:
    """Joue un tour. Retourne le nombre de lancers réussis."""
    cfg = ctx.config
    ctx.log("Mon tour.")
    time.sleep(cfg.turn_start_delay_s)
    casts = 0
    while casts < cfg.casts_per_turn and not should_stop():
        if not _select_spell(ctx):
            break
        scene, (ox, oy) = ctx.capture.grab()
        enemies, me = find_enemies(scene), find_me(scene, ctx.me_hint)
        if me:
            ctx.me_hint = me.center
        if not enemies:
            ctx.log("Aucun adversaire visible.")
            break
        mask = range_mask(scene)
        if me:
            origin = me.center
        else:
            ys, xs = np.where(mask > 0)
            origin = (int(xs.mean()), int(ys.mean())) if len(xs) else enemies[0].center
        in_range = [f for f in sort_by_distance(enemies, origin)
                    if range_fraction(mask, f.center) >= cfg.range_min_fraction]
        ctx.log(f"{len(enemies)} adversaire(s), {len(in_range)} à portée.")
        if not in_range:
            ctx.log("Aucun adversaire à portée : je passe le tour.")
            break
        done = False
        for target in in_range[:3]:
            dist = grid_distance(target.center, origin)
            ctx.log(f"Cible à {dist:.1f} case(s) en {target.center}.")
            _diag(ctx, scene, enemies, me, target)
            inp.click(ox + target.cx, oy + target.cy - 4)
            ok, (ox2, oy2) = _wait_confirm(ctx)
            if ok:
                inp.click(ox2 + ok.center[0], oy2 + ok.center[1])
                casts += 1
                ctx.log(f"✔ Lancer {casts}/{cfg.casts_per_turn} confirmé.")
                time.sleep(1.5)                       # animation + dégâts
                done = True
                break
            ctx.log("Pas de confirmation sur cette cible.")
            if not _select_spell(ctx):
                break
            scene, (ox, oy) = ctx.capture.grab()
        if not done:
            break
    return casts


def end_turn(ctx: Context) -> bool:
    scene, (ox, oy) = ctx.capture.grab()
    r = read_ui(scene, ctx.ui_templates, ctx.config.ui_threshold)
    fin = r.found.get("fin_du_tour")
    if not fin or not r.turn_active:
        ctx.log("⚠ Bouton « Fin du tour » vert introuvable.")
        return False
    inp.click(ox + fin.center[0], oy + fin.center[1])
    t0 = time.time()
    while time.time() - t0 < 6:
        time.sleep(0.4)
        s, _ = ctx.capture.grab()
        if not read_ui(s, ctx.ui_templates, ctx.config.ui_threshold).turn_active:
            ctx.log("Tour terminé.")
            return True
    ctx.log("⚠ Le tour ne semble pas terminé.")
    return False


def run_turns(ctx: Context, should_stop) -> None:
    """Boucle des tours : attendre mon tour, jouer, finir, recommencer."""
    ctx.log("Phases 4-5 : je joue les tours (F12 pour arrêter).")
    n = 0
    while not should_stop():
        if not wait_my_turn(ctx, should_stop):
            if not should_stop():
                ctx.log(f"Aucun tour à jouer pendant {ctx.config.turn_wait_s} s : "
                        "combat terminé ? Le programme s'arrête.")
            return
        n += 1
        ctx.log(f"── Tour {n} ──")
        play_turn(ctx, should_stop)
        if should_stop():
            return
        end_turn(ctx)
    ctx.log("Arrêté.")


def test_combat(ctx: Context) -> np.ndarray:
    """Diagnostic sans clic : adversaires, mon personnage, portée."""
    scene, _ = ctx.capture.grab()
    enemies, me = find_enemies(scene), find_me(scene, ctx.me_hint)
    if me:
        ctx.me_hint = me.center
    mask = range_mask(scene)
    visible = range_visible(scene)
    ctx.log(f"Mon personnage : {me.center if me else 'introuvable'} · {len(enemies)} adversaire(s) · "
            f"portée du sort {'affichée' if visible else 'non affichée (sélectionne d’abord le sort)'}")
    origin = me.center if me else None
    for f in (sort_by_distance(enemies, origin) if origin else enemies):
        frac = range_fraction(mask, f.center)
        dist = f"{grid_distance(f.center, origin):.1f} case(s)" if origin else "?"
        ctx.log(f"  adversaire {f.center} : {dist}" + (f" · {'À PORTÉE' if frac >= ctx.config.range_min_fraction else 'hors portée'}"
                                                        if visible else ""))
    out = scene.copy()
    out[mask > 0] = (0.55 * out[mask > 0] + 0.45 * np.array([0, 255, 0])).astype(np.uint8)
    for f in enemies:
        cv2.circle(out, f.center, 9, (0, 255, 255), -1)
    if me:
        cv2.circle(out, me.center, 11, (0, 0, 255), -1)
    return out
