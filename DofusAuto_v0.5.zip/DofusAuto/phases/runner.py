"""Enchaîne les phases : recherche (1) -> détection du combat (2)."""
import time

from phases.base import Context
from phases.p1_recherche import scan_once
from phases.p2_combat import wait_for_combat
from phases.p3_placement import run_placement
from phases.p4_tour import run_turns


def _sleep(seconds: float, should_stop) -> None:
    end = time.time() + seconds
    while time.time() < end and not should_stop():
        time.sleep(0.05)


def run_phases(ctx: Context, should_stop, on_frame=None) -> None:
    cfg = ctx.config
    ctx.log("Démarré. Appuie sur F12 pour arrêter.")
    while not should_stop():
        pause = cfg.scan_interval_ms / 1000
        try:
            out = scan_once(ctx, do_click=True)             # phase 1
            if on_frame:
                on_frame(out.frame)
            if out.clicked:
                if cfg.detect_combat:
                    if wait_for_combat(ctx, should_stop, on_frame):   # phase 2
                        if cfg.do_placement:
                            if run_placement(ctx, should_stop, on_frame):   # phase 3
                                if cfg.do_turns:
                                    run_turns(ctx, should_stop)             # phases 4-5
                                    ctx.log("Le programme s'arrête ici : la fin du combat (phase 6) "
                                            "n'est pas encore construite.")
                                else:
                                    ctx.log("Phase 3 validée. Le programme s'arrête ici.")
                            else:
                                ctx.log("Phase 3 non aboutie : le programme s'arrête, reprends la main.")
                        else:
                            ctx.log("Phase 2 validée. Le programme s'arrête ici.")
                        return
                else:
                    pause = cfg.cooldown_after_click_s
        except Exception as e:                              # fenêtre introuvable, etc.
            ctx.log(f"⚠ {e}")
            pause = 2.0
        _sleep(pause, should_stop)
    ctx.log("Arrêté.")
