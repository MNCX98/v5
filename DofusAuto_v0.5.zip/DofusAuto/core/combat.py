"""Vision du combat : anneaux sous les combattants, portée du sort (violet), distances."""
from dataclasses import dataclass

import cv2
import numpy as np

from core.grid import grid_distance


@dataclass
class Fighter:
    cx: int
    cy: int
    pixels: int
    w: int = 0
    h: int = 0

    @property
    def center(self) -> tuple[int, int]:
        return self.cx, self.cy


def _game_roi(h: int, w: int) -> np.ndarray:
    roi = np.zeros((h, w), bool)
    roi[int(0.05 * h):int(0.955 * h), int(0.17 * w):int(0.83 * w)] = True
    roi[:int(0.27 * h), :int(0.48 * w)] = False        # barre d'ordre de jeu (barres bleues/rouges des portraits)
    roi[:int(0.5 * h), :int(0.215 * w)] = False        # colonne d'icônes orange/rouges à gauche
    return roi


def _hsv(scene):
    return cv2.split(cv2.cvtColor(scene, cv2.COLOR_BGR2HSV))


def _rings(mask: np.ndarray, min_pixels: int = 35, merge=(31, 15)) -> list[tuple[Fighter, float]]:
    """Regroupe les morceaux d'anneau voisins ; retourne (combattant, taux de remplissage)."""
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, merge)
    joined = cv2.dilate(mask, k)
    n, lab, _, _ = cv2.connectedComponentsWithStats(joined)
    out = []
    for i in range(1, n):
        ys, xs = np.where((lab == i) & (mask > 0))
        if len(xs) < min_pixels:
            continue
        x0, x1, y0, y1 = xs.min(), xs.max(), ys.min(), ys.max()
        fill = len(xs) / max(1, (x1 - x0 + 1) * (y1 - y0 + 1))
        out.append((Fighter(int((x0 + x1) // 2), int((y0 + y1) // 2), len(xs),
                            int(x1 - x0 + 1), int(y1 - y0 + 1)), fill))
    return out


def find_enemies(scene: np.ndarray) -> list[Fighter]:
    """Adversaires : anneau bleu sous chaque monstre."""
    h, w = scene.shape[:2]
    hh, ss, vv = _hsv(scene)
    m = (((hh > 98) & (hh < 112) & (ss > 140) & (vv > 140)) & _game_roi(h, w)).astype(np.uint8) * 255
    return [f for f, _ in _rings(m)]


def find_me(scene: np.ndarray, hint: tuple[int, int] | None = None) -> Fighter | None:
    """Mon personnage : anneau rouge (ellipse d'environ 48×25 px, en mode normal comme en mode créature).

    On écarte les chiffres de dégâts rouges (plus gros), les cases rouges et les icônes rouges.
    `hint` : position connue (mon personnage ne bouge pas pendant le combat) pour départager.
    """
    h, w = scene.shape[:2]
    hh, ss, vv = _hsv(scene)
    m = ((((hh < 8) | (hh > 172)) & (ss > 120) & (vv > 120)) & _game_roi(h, w)).astype(np.uint8) * 255
    cands = [f for f, fill in _rings(m, min_pixels=120)
             if 120 <= f.pixels <= 650 and 40 <= f.w <= 60 and 15 <= f.h <= 40 and f.w / f.h >= 1.3 and fill < 0.6]
    if not cands:
        return None
    if hint is not None:
        near = [f for f in cands if abs(f.cx - hint[0]) <= 20 and abs(f.cy - hint[1]) <= 20]
        if near:
            return near[0]
    return max(cands, key=lambda f: f.pixels)


def range_mask(scene: np.ndarray) -> np.ndarray:
    """Cases où le sort sélectionné peut être lancé (violet affiché par le jeu)."""
    h, w = scene.shape[:2]
    hh, ss, vv = _hsv(scene)
    m = ((hh > 118) & (hh < 127) & (ss > 110) & (vv > 150) & _game_roi(h, w)).astype(np.uint8)
    return m


def range_visible(scene: np.ndarray, min_pixels: int = 3000) -> bool:
    return int(range_mask(scene).sum()) >= min_pixels


def range_fraction(mask: np.ndarray, center: tuple[int, int], half=(34, 15)) -> float:
    """Part de violet autour d'un point (case d'un adversaire)."""
    x, y = center
    h, w = mask.shape
    patch = mask[max(0, y - half[1]):min(h, y + half[1]), max(0, x - half[0]):min(w, x + half[0])]
    return float(patch.mean()) if patch.size else 0.0


def sort_by_distance(fighters: list[Fighter], origin: tuple[int, int]) -> list[Fighter]:
    return sorted(fighters, key=lambda f: grid_distance(f.center, origin))
