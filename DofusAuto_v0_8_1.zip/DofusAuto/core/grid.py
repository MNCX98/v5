"""Cases de la grille isométrique (détection par couleur) et distances en cases."""
from dataclasses import dataclass

import cv2
import numpy as np

# Pas entre deux cases voisines (en pixels), mesuré pour BlueStacks en 1920×1020.
PITCH_X = 44.0
PITCH_Y = 22.0


@dataclass
class Cell:
    cx: int
    cy: int
    area: int
    w: int
    h: int

    @property
    def center(self) -> tuple[int, int]:
        return self.cx, self.cy


def grid_distance(a: tuple[float, float], b: tuple[float, float]) -> float:
    """Distance en cases (déplacement sur la grille, comme dans Dofus)."""
    gx = abs(a[0] - b[0]) / PITCH_X
    gy = abs(a[1] - b[1]) / PITCH_Y
    return max(gx, gy)


def find_cells(scene: np.ndarray, color: str, min_area: int = 400) -> list[Cell]:
    """Cases de placement visibles : 'red' = les miennes, 'blue' = celles des monstres."""
    h, w = scene.shape[:2]
    hsv = cv2.cvtColor(scene, cv2.COLOR_BGR2HSV)
    hh, ss, vv = cv2.split(hsv)
    if color == "red":
        m = ((hh < 8) | (hh > 172)) & (ss > 150) & (vv > 150)
    elif color == "blue":
        m = (hh > 98) & (hh < 108) & (ss > 150) & (vv > 150)
    else:
        raise ValueError(color)
    roi = np.zeros((h, w), bool)                      # zone de jeu : on exclut barre du haut et menus
    roi[int(0.28 * h):int(0.955 * h), int(0.17 * w):int(0.83 * w)] = True
    mask = (m & roi).astype(np.uint8) * 255
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    n, _, stats, cents = cv2.connectedComponentsWithStats(mask)
    cells = []
    for i in range(1, n):
        x, y, bw, bh, area = (int(v) for v in stats[i])
        if area < min_area or bh == 0:
            continue
        ratio = bw / bh
        if not (1.4 <= ratio <= 3.0) or bw > 80 or bh > 42:      # forme de losange, taille d'une case
            continue
        cells.append(Cell(int(cents[i][0]), int(cents[i][1]), area, bw, bh))
    return cells
