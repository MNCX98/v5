"""Phase 1 : recherche des monstres et clic sur la meilleure correspondance."""
import time
from datetime import datetime
from dataclasses import dataclass

import numpy as np

from core import input as inp
from core.imgio import save_image
from core.paths import logs_dir
from core.vision import Detection, annotate, scan
from phases.base import Context


@dataclass
class ScanOutcome:
    frame: np.ndarray              # image annotée à afficher
    detection: Detection | None    # cible choisie (ou None)
    clicked: bool


def game_area(h: int, w: int) -> tuple[int, int, int, int]:
    """Fenêtre de jeu (x0, y0, x1, y1) : écarte pubs, menus et barres de BlueStacks."""
    return int(0.17 * w), int(0.05 * h), int(0.83 * w), int(0.955 * h)


def _in_game_area(d: Detection, h: int, w: int) -> bool:
    x0, y0, x1, y1 = game_area(h, w)
    cx, cy = d.center
    return x0 <= cx <= x1 and y0 <= cy <= y1


def scan_once(ctx: Context, do_click: bool) -> ScanOutcome:
    """Une observation : capture -> recherche -> (clic éventuel)."""
    t0 = time.time()
    scene, (ox, oy) = ctx.capture.grab()
    t1 = time.time()
    sh, sw = scene.shape[:2]
    gx0, gy0, gx1, gy1 = game_area(sh, sw)             # on ne cherche que dans la fenêtre de jeu
    result = scan(scene[gy0:gy1, gx0:gx1], ctx.templates, ctx.config.threshold, ctx.config.color_tolerance)
    for d in result.detections + result.rejected:      # retour aux coordonnées de l'image entière
        d.x += gx0
        d.y += gy0
    ms_cap, ms_scan = (t1 - t0) * 1000, (time.time() - t1) * 1000

    if not result.detections:
        best = max(result.best_scores.values(), default=0.0)
        ctx.log(f"Aucune cible (meilleur score {best:.2f}, seuil {ctx.config.threshold:.2f}) "
                f"· image {sw}×{sh} · capture {ms_cap:.0f} ms, analyse {ms_scan:.0f} ms")
        if result.rejected:
            r = result.rejected[0]
            ctx.log(f"  {len(result.rejected)} forme(s) écartée(s) pour couleurs différentes "
                    f"(la plus proche : {r.monster}/{r.variant} score {r.score:.2f}, écart de couleur "
                    f"{r.color_diff:.0f} > {ctx.config.color_tolerance:.0f}). Si c'est un vrai monstre, "
                    f"augmente color_tolerance dans config.json.")
        return ScanOutcome(annotate(scene, []), None, False)

    target = result.detections[0]          # la plus fiable
    cx, cy = target.center
    ctx.log(f"Cible : {target.monster}/{target.variant} score {target.score:.2f} "
            f"(écart couleur {target.color_diff:.0f}) en ({cx}, {cy}) — {len(result.detections)} détection(s) · analyse {ms_scan:.0f} ms")
    clicked = False
    if do_click:
        n = max(1, int(ctx.config.click_count))
        for i in range(n):
            inp.click(ox + cx, oy + cy)
            if i < n - 1:
                time.sleep(ctx.config.click_interval_ms / 1000)
        clicked = True
        ctx.log(f"{'Double clic' if n == 2 else str(n) + ' clic(s)'} effectué en ({cx}, {cy})")
    frame = annotate(scene, result.detections, (cx, cy) if clicked else None)
    if ctx.config.save_diagnostics:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        save_image(logs_dir() / f"diag_{stamp}.png", frame)
    return ScanOutcome(frame, target, clicked)
