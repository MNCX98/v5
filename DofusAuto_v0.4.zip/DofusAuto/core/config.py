"""Réglages de l'application, stockés dans config.json à côté du .exe."""
import json
from dataclasses import asdict, dataclass, fields
from pathlib import Path


@dataclass
class Config:
    window_title_contains: str = "BlueStacks"   # partie du titre de la fenêtre à observer
    threshold: float = 0.80                     # confiance minimale (0.50 à 0.99)
    scan_interval_ms: int = 500                 # pause entre deux observations
    cooldown_after_click_s: float = 4.0         # pause après un clic (laisse le jeu réagir)
    click_count: int = 2                        # 1 = simple clic, 2 = double clic
    click_interval_ms: int = 200                # délai entre deux clics d'un double clic
    detect_combat: bool = True                  # phase 2 : attendre le combat après le clic
    combat_wait_s: int = 20                     # attente maximale du bouton « Prêt »
    ui_threshold: float = 0.85                  # confiance minimale pour les boutons du jeu
    do_placement: bool = True                   # phase 3 : se placer puis cliquer sur « Prêt »
    placement_rule: str = "closest"             # closest = plus proche des monstres, farthest, stay
    sequence_seconds: int = 40                  # durée de l'enregistrement de séquence
    save_diagnostics: bool = True               # enregistre une image annotée à chaque clic


def load_config(path: Path) -> Config:
    cfg = Config()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        known = {f.name for f in fields(Config)}
        for k, v in data.items():
            if k in known:
                setattr(cfg, k, v)
    except (FileNotFoundError, ValueError):
        pass
    return cfg


def save_config(cfg: Config, path: Path) -> None:
    path.write_text(json.dumps(asdict(cfg), indent=2, ensure_ascii=False), encoding="utf-8")
