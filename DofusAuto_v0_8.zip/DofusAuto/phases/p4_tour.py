"""Phases 4 et 5 : jouer mon tour (lancer le sort sur l'adversaire le plus proche à portée,
puis finir le tour) et recommencer à chaque tour."""
import time
from datetime import datetime

import cv2
import numpy as np

from core import input as inp
from core.combat import (find_enemies, find_me, range_fraction, range_mask, range_visible,
                         sort_by_distance)
from core.grid import grid_distance
from core.imgio import save_image
from core.paths import logs_dir
from core.vision import scan
from phases.base import Context
from phases.p2_combat import find_ui, read_ui


def _find(ctx: Context, scene, name: str):
    return find_ui(ctx, scene, name)


def wait_my_turn(ctx: Context, should_stop) -> str:
    """Attend mon tour. Retourne 'turn', 'over' (fenêtre de résultat), 'timeout' ou 'stopped'."""
    t0 = time.time()
    while time.time() - t0 < ctx.config.turn_wait_s and not should_stop():
        scene, _ = ctx.capture.grab()
        r = read_ui(scene, ctx.ui_templates, ctx.config.ui_threshold)
        if "resultat_titre" in r.found:
            return "over"
        if r.turn_active:
            return "turn"
        time.sleep(0.4)
    return "stopped" if should_stop() else "timeout"


def _diag(ctx: Context, scene, enemies, me, target=None, label="tour"):
    if not ctx.config.save_diagnostics:
        return
    out = scene.copy()
    for f in enemies:
        cv2.circle(out, f.center, 8, (0, 255, 255), -1)
    if me:
        cv2.circle(out, me.center, 10, (0, 0, 255), -1)
    if target:
        cv2.circle(out, target.center, 22, (0, 255, 0), 3)
    save_image(logs_dir() / f"{label}_{datetime.now():%Y%m%d_%H%M%S_%f}.png", out)


def _wait_confirm(ctx: Context, timeout: float = 1.6):
    t0 = time.time()
    while time.time() - t0 < timeout:
        scene, origin = ctx.capture.grab()
        d = _find(ctx, scene, "valider")
        if d:
            return d, origin
        time.sleep(0.2)
    return None, (0, 0)


def _game_signature(scene: np.ndarray) -> np.ndarray:
    """Version réduite de la zone de jeu (niveaux de gris), pour savoir si l'écran bouge encore."""
    h, w = scene.shape[:2]
    roi = scene[int(0.05 * h):int(0.955 * h), int(0.17 * w):int(0.83 * w)]
    small = cv2.resize(roi, (480, 270), interpolation=cv2.INTER_AREA)
    return cv2.cvtColor(small, cv2.COLOR_BGR2GRAY).astype(np.int16)


def _screen_moving(a: np.ndarray, b: np.ndarray) -> bool:
    """Vrai si une partie notable de l'écran a changé (animation, chiffres de dégâts qui montent…)."""
    return float((np.abs(a - b) > 30).mean()) > 0.0004


def _wait_after_cast(ctx: Context, should_stop) -> str:
    """Attend la fin du lancer : animation du sort, dégâts, mort éventuelle du monstre.

    Retourne 'over' si la fenêtre de résultat est apparue (dernier monstre mort), sinon 'ok'.
    """
    cfg = ctx.config
    t0 = time.time()
    prev, calm = None, 0
    while time.time() - t0 < cfg.cast_settle_max_s and not should_stop():
        time.sleep(0.3)
        scene, _ = ctx.capture.grab()
        if _find(ctx, scene, "resultat_titre"):
            ctx.log("Fenêtre de résultat : le combat est terminé.")
            return "over"
        sig = _game_signature(scene)
        calm = calm + 1 if (prev is not None and not _screen_moving(prev, sig)) else 0
        prev = sig
        if time.time() - t0 >= cfg.cast_settle_s and calm >= 2:
            break
    return "ok"


def _target_survived(scene, target) -> bool:
    """Un anneau d'adversaire est-il encore sous la cible ? (sinon le monstre est mort)"""
    for f in find_enemies(scene):
        if abs(f.cx - target.cx) <= 24 and abs(f.cy - target.cy) <= 14:
            return True
    return False


def _wait_result(ctx: Context, should_stop) -> bool:
    """Plus aucun adversaire à l'écran : attend la fenêtre « Résultat du combat »."""
    t0 = time.time()
    while time.time() - t0 < ctx.config.result_wait_s and not should_stop():
        scene, _ = ctx.capture.grab()
        if _find(ctx, scene, "resultat_titre"):
            return True
        time.sleep(0.4)
    return False


def _select_spell(ctx: Context) -> bool:
    scene, (ox, oy) = ctx.capture.grab()
    if range_visible(scene):
        return True                                   # déjà sélectionné
    icon = _find(ctx, scene, "sort_attaque")
    if not icon:
        ctx.log("⚠ Icône du sort introuvable.")
        return False
    inp.click(ox + icon.center[0], oy + icon.center[1])
    t0 = time.time()
    while time.time() - t0 < 1.8:
        time.sleep(0.3)
        s, _ = ctx.capture.grab()
        if range_visible(s):
            return True
    ctx.log("Le sort ne s'affiche pas (plus assez de PA ?).")
    return False


def play_turn(ctx: Context, should_stop) -> tuple[int, bool]:
    """Joue un tour. Retourne (nombre de lancers réussis, combat terminé)."""
    cfg = ctx.config
    ctx.log("Mon tour.")
    time.sleep(cfg.turn_start_delay_s)
    casts = 0
    over = False
    while casts < cfg.casts_per_turn and not should_stop():
        scene0, _ = ctx.capture.grab()
        if _find(ctx, scene0, "resultat_titre"):
            ctx.log("Le combat est terminé.")
            over = True
            break
        if not _select_spell(ctx):
            break
        scene, (ox, oy) = ctx.capture.grab()
        enemies, me = find_enemies(scene), find_me(scene, ctx.me_hint)
        if me:
            ctx.me_hint = me.center
        if not enemies:
            ctx.log("Aucun adversaire visible.")
            break
        mask = range_mask(scene)
        if me:
            origin = me.center
        else:
            ys, xs = np.where(mask > 0)
            origin = (int(xs.mean()), int(ys.mean())) if len(xs) else enemies[0].center
        in_range = [f for f in sort_by_distance(enemies, origin)
                    if range_fraction(mask, f.center) >= cfg.range_min_fraction]
        ctx.log(f"{len(enemies)} adversaire(s), {len(in_range)} à portée.")
        if not in_range:
            ctx.log("Aucun adversaire à portée : je passe le tour.")
            break
        done = False
        for target in in_range[:3]:
            dist = grid_distance(target.center, origin)
            ctx.log(f"Cible à {dist:.1f} case(s) en {target.center}.")
            _diag(ctx, scene, enemies, me, target)
            inp.click(ox + target.cx, oy + target.cy - 4)
            ok, (ox2, oy2) = _wait_confirm(ctx)
            if ok:
                inp.click(ox2 + ok.center[0], oy2 + ok.center[1])
                casts += 1
                ctx.log(f"✔ Lancer {casts}/{cfg.casts_per_turn} confirmé.")
                if _wait_after_cast(ctx, should_stop) == "over":     # animation + dégâts + mort éventuelle
                    over = True
                    done = True
                    break
                after, _ = ctx.capture.grab()
                if _target_survived(after, target):
                    ctx.log("Le monstre est toujours en vie.")
                else:
                    ctx.log("☠ Le monstre ciblé est mort.")
                    if not find_enemies(after):
                        ctx.log("Plus aucun adversaire : j'attends la fenêtre de résultat.")
                        if _wait_result(ctx, should_stop):
                            over = True
                        done = True
                        break
                done = True
                break
            ctx.log("Pas de confirmation sur cette cible.")
            if not _select_spell(ctx):
                break
            scene, (ox, oy) = ctx.capture.grab()
        if not done or over:
            break
    return casts, over


def end_turn(ctx: Context) -> bool:
    scene, (ox, oy) = ctx.capture.grab()
    r = read_ui(scene, ctx.ui_templates, ctx.config.ui_threshold)
    fin = r.found.get("fin_du_tour")
    if "resultat_titre" in r.found:
        ctx.log("Le combat est terminé.")
        return False
    if not fin or not r.turn_active:
        ctx.log("⚠ Bouton « Fin du tour » vert introuvable.")
        return False
    inp.click(ox + fin.center[0], oy + fin.center[1])
    t0 = time.time()
    while time.time() - t0 < 6:
        time.sleep(0.4)
        s, _ = ctx.capture.grab()
        if not read_ui(s, ctx.ui_templates, ctx.config.ui_threshold).turn_active:
            ctx.log("Tour terminé.")
            return True
    ctx.log("⚠ Le tour ne semble pas terminé.")
    return False


def run_turns(ctx: Context, should_stop) -> str:
    """Boucle des tours. Retourne 'over' (combat terminé), 'timeout' ou 'stopped'."""
    ctx.log("Phases 4-5 : je joue les tours (F12 pour arrêter).")
    n = 0
    while not should_stop():
        status = wait_my_turn(ctx, should_stop)
        if status == "over":
            ctx.log("Le combat est terminé (fenêtre de résultat).")
            return "over"
        if status == "timeout":
            ctx.log(f"Aucun tour à jouer pendant {ctx.config.turn_wait_s} s : le programme s'arrête.")
            return "timeout"
        if status == "stopped":
            break
        n += 1
        ctx.log(f"── Tour {n} ──")
        _, over = play_turn(ctx, should_stop)
        if over:
            ctx.log("Le combat est terminé (fenêtre de résultat).")
            return "over"
        if should_stop():
            break
        end_turn(ctx)
    return "stopped"


def test_combat(ctx: Context) -> np.ndarray:
    """Diagnostic sans clic : adversaires, mon personnage, portée."""
    scene, _ = ctx.capture.grab()
    enemies, me = find_enemies(scene), find_me(scene, ctx.me_hint)
    if me:
        ctx.me_hint = me.center
    mask = range_mask(scene)
    visible = range_visible(scene)
    ctx.log(f"Mon personnage : {me.center if me else 'introuvable'} · {len(enemies)} adversaire(s) · "
            f"portée du sort {'affichée' if visible else 'non affichée (sélectionne d’abord le sort)'}")
    origin = me.center if me else None
    for f in (sort_by_distance(enemies, origin) if origin else enemies):
        frac = range_fraction(mask, f.center)
        dist = f"{grid_distance(f.center, origin):.1f} case(s)" if origin else "?"
        ctx.log(f"  adversaire {f.center} : {dist}" + (f" · {'À PORTÉE' if frac >= ctx.config.range_min_fraction else 'hors portée'}"
                                                        if visible else ""))
    out = scene.copy()
    out[mask > 0] = (0.55 * out[mask > 0] + 0.45 * np.array([0, 255, 0])).astype(np.uint8)
    for f in enemies:
        cv2.circle(out, f.center, 9, (0, 255, 255), -1)
    if me:
        cv2.circle(out, me.center, 11, (0, 0, 255), -1)
    return out
